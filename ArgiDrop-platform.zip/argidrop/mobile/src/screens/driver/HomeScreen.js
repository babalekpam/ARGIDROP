// Driver Home — map with nearby jobs, online/offline toggle, current active delivery
import React, { useEffect, useState, useRef, useCallback } from 'react';
import { View, Text, TouchableOpacity, ScrollView, StyleSheet, Switch, FlatList, RefreshControl } from 'react-native';
import MapView, { Marker, PROVIDER_GOOGLE } from 'react-native-maps';
import * as Location from 'expo-location';
import { useAuth } from '../../context/AuthContext';
import { useSocket } from '../../context/SocketContext';
import api from '../../utils/api';

const C = { cream: '#F7F3EB', paper: '#FDFBF6', forest: '#1B4332', forestSoft: '#2D5E3E', bronze: '#8B6F47', ink: '#1A1A1A', muted: '#6B6560', subtle: '#9A9489', border: '#E4DCC9', success: '#2D5E3E' };

export default function HomeScreen({ navigation }) {
  const { user } = useAuth();
  const { getSocket } = useSocket();
  const [isOnline, setIsOnline] = useState(false);
  const [location, setLocation] = useState(null);
  const [availableJobs, setAvailableJobs] = useState([]);
  const [activeJob, setActiveJob] = useState(null);
  const [todayStats, setTodayStats] = useState({ earnings: 0, deliveries: 0 });
  const [refreshing, setRefreshing] = useState(false);
  const locationSub = useRef(null);
  const mapRef = useRef(null);

  const loadJobs = useCallback(async () => {
    if (!location) return;
    try {
      const res = await api.get(`/jobs/available?lat=${location.latitude}&lng=${location.longitude}&radius=15`);
      setAvailableJobs(res.data.jobs || []);
    } catch (err) { console.error('Load jobs error:', err.message); }
  }, [location]);

  const loadActiveJob = async () => {
    try {
      const res = await api.get('/jobs?status=IN_TRANSIT&limit=1');
      const active = res.data.jobs?.[0];
      if (!active) {
        const matched = await api.get('/jobs?status=MATCHED&limit=1');
        setActiveJob(matched.data.jobs?.[0] || null);
      } else setActiveJob(active);
    } catch {}
  };

  const loadStats = async () => {
    try {
      const res = await api.get('/drivers/earnings');
      setTodayStats({ earnings: parseFloat(res.data.thisMonth || 0), deliveries: res.data.totalDeliveries || 0 });
    } catch {}
  };

  useEffect(() => {
    (async () => {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') return;
      const loc = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.High });
      setLocation(loc.coords);
    })();
    loadActiveJob();
    loadStats();
  }, []);

  useEffect(() => { loadJobs(); }, [location, loadJobs]);

  // Start/stop location sharing when going online
  useEffect(() => {
    if (isOnline) {
      (async () => {
        locationSub.current = await Location.watchPositionAsync(
          { accuracy: Location.Accuracy.High, timeInterval: 15000, distanceInterval: 50 },
          loc => {
            setLocation(loc.coords);
            api.patch('/drivers/location', { lat: loc.coords.latitude, lng: loc.coords.longitude }).catch(()=>{});
            getSocket()?.emit('driver:location', { lat: loc.coords.latitude, lng: loc.coords.longitude });
          }
        );
        api.patch('/drivers/online', { online: true }).catch(()=>{});
      })();
    } else {
      locationSub.current?.remove();
      api.patch('/drivers/online', { online: false }).catch(()=>{});
    }
    return () => locationSub.current?.remove();
  }, [isOnline]);

  // Socket job alerts
  useEffect(() => {
    const socket = getSocket();
    if (!socket) return;
    const handler = (job) => {
      if (isOnline) navigation.navigate('JobAlert', { jobId: job.id });
    };
    socket.on('job:available', handler);
    return () => socket.off('job:available', handler);
  }, [isOnline]);

  const onRefresh = async () => {
    setRefreshing(true);
    await Promise.all([loadJobs(), loadActiveJob(), loadStats()]);
    setRefreshing(false);
  };

  return (
    <ScrollView style={{ flex: 1, backgroundColor: C.cream }}
      refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={C.forest} />}>
      {/* Header */}
      <View style={s.header}>
        <View style={{ flex: 1 }}>
          <Text style={s.greeting}>Hello, {user?.firstName}</Text>
          <Text style={s.date}>{new Date().toLocaleDateString('fr-FR', { weekday: 'long', day: 'numeric', month: 'long' })}</Text>
        </View>
        <View style={{ alignItems: 'flex-end' }}>
          <Text style={s.onlineLabel}>{isOnline ? 'Online' : 'Offline'}</Text>
          <Switch value={isOnline} onValueChange={setIsOnline}
            trackColor={{ false: C.border, true: C.forestSoft }}
            thumbColor={isOnline ? C.forest : C.subtle} />
        </View>
      </View>

      {/* Active delivery banner */}
      {activeJob && (
        <TouchableOpacity style={s.activeBanner} onPress={() => navigation.navigate('ActiveDelivery', { jobId: (activeJob.job || activeJob).id })}>
          <View style={{ flex: 1 }}>
            <Text style={s.activeLabel}>ACTIVE DELIVERY</Text>
            <Text style={s.activeAddr} numberOfLines={1}>{(activeJob.job || activeJob).dropoffAddress}</Text>
            <Text style={s.activePrice}>{(activeJob.job || activeJob).priceOffered} {(activeJob.job || activeJob).currency}</Text>
          </View>
          <Text style={s.activeAction}>Continue →</Text>
        </TouchableOpacity>
      )}

      {/* Earnings card */}
      <View style={s.earningsCard}>
        <View style={{ flex: 1 }}>
          <Text style={s.cardLabel}>THIS MONTH</Text>
          <Text style={s.cardAmount}>{Math.round(todayStats.earnings).toLocaleString()}</Text>
          <Text style={s.cardCurrency}>XOF earned</Text>
        </View>
        <View style={s.cardDivider} />
        <View style={{ flex: 1 }}>
          <Text style={s.cardLabel}>DELIVERIES</Text>
          <Text style={s.cardAmount}>{todayStats.deliveries}</Text>
          <Text style={s.cardCurrency}>all time</Text>
        </View>
      </View>

      {/* Map */}
      {location && (
        <View style={s.mapWrap}>
          <MapView
            ref={mapRef}
            style={{ height: 240 }}
            provider={PROVIDER_GOOGLE}
            showsUserLocation
            initialRegion={{ latitude: location.latitude, longitude: location.longitude, latitudeDelta: 0.04, longitudeDelta: 0.04 }}>
            {availableJobs.map(({ job }) => job.pickupLat && (
              <Marker key={job.id} coordinate={{ latitude: parseFloat(job.pickupLat), longitude: parseFloat(job.pickupLng) }}
                title={`${job.priceOffered} ${job.currency}`} description={job.packageType}
                pinColor={C.forest} />
            ))}
          </MapView>
        </View>
      )}

      {/* Available jobs */}
      <View style={s.jobsSection}>
        <View style={s.sectionHeader}>
          <Text style={s.sectionTitle}>Available near you</Text>
          <Text style={s.sectionCount}>{availableJobs.length} {availableJobs.length === 1 ? 'job' : 'jobs'}</Text>
        </View>

        {!isOnline ? (
          <View style={s.emptyState}>
            <Text style={s.emptyTitle}>Go online to receive jobs</Text>
            <Text style={s.emptyText}>Turn on the switch above to see available deliveries.</Text>
          </View>
        ) : availableJobs.length === 0 ? (
          <View style={s.emptyState}>
            <Text style={s.emptyTitle}>No jobs nearby right now</Text>
            <Text style={s.emptyText}>We'll notify you the moment one appears.</Text>
          </View>
        ) : (
          availableJobs.slice(0, 10).map(({ job }) => (
            <TouchableOpacity key={job.id} style={s.jobCard}
              onPress={() => navigation.navigate('JobDetail', { jobId: job.id })}>
              <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 10 }}>
                <View style={s.urgencyChip}>
                  <Text style={s.urgencyText}>{job.urgency || 'STANDARD'}</Text>
                </View>
                <Text style={s.jobPrice}>{job.priceOffered} {job.currency}</Text>
              </View>
              <View style={{ flexDirection: 'row', gap: 10, marginBottom: 4 }}>
                <View style={{ width: 3, backgroundColor: C.bronze, borderRadius: 2 }} />
                <Text style={s.jobAddr} numberOfLines={1}>{job.pickupAddress}</Text>
              </View>
              <View style={{ flexDirection: 'row', gap: 10 }}>
                <View style={{ width: 3, backgroundColor: C.forest, borderRadius: 2 }} />
                <Text style={s.jobAddr} numberOfLines={1}>{job.dropoffAddress}</Text>
              </View>
              <Text style={s.jobMeta}>{job.packageType} {job.weightKg ? `· ${job.weightKg} kg` : ''}</Text>
            </TouchableOpacity>
          ))
        )}
      </View>
      <View style={{ height: 32 }} />
    </ScrollView>
  );
}

const s = StyleSheet.create({
  header: { flexDirection: 'row', alignItems: 'center', padding: 20, paddingTop: 48, paddingBottom: 16 },
  greeting: { fontSize: 22, fontWeight: '500', color: C.ink },
  date: { fontSize: 12, color: C.muted, marginTop: 2 },
  onlineLabel: { fontSize: 10, color: C.muted, letterSpacing: 1, fontWeight: '600', marginBottom: 6 },
  activeBanner: { margin: 20, marginTop: 4, backgroundColor: C.forest, borderRadius: 8, padding: 16, flexDirection: 'row', alignItems: 'center' },
  activeLabel: { fontSize: 10, color: '#C4D4C8', letterSpacing: 1.5, fontWeight: '700', marginBottom: 4 },
  activeAddr: { fontSize: 14, color: C.paper, fontWeight: '500', marginBottom: 4 },
  activePrice: { fontSize: 18, color: C.paper, fontWeight: '600' },
  activeAction: { fontSize: 13, color: C.paper, fontWeight: '500' },
  earningsCard: { flexDirection: 'row', margin: 20, marginTop: 4, backgroundColor: C.paper, borderWidth: 1, borderColor: C.border, borderRadius: 8, padding: 20 },
  cardLabel: { fontSize: 10, color: C.muted, letterSpacing: 1.2, fontWeight: '600', marginBottom: 8 },
  cardAmount: { fontSize: 26, fontWeight: '500', color: C.ink, lineHeight: 30 },
  cardCurrency: { fontSize: 11, color: C.subtle, marginTop: 2 },
  cardDivider: { width: 1, backgroundColor: C.border, marginHorizontal: 16 },
  mapWrap: { marginHorizontal: 20, borderRadius: 8, overflow: 'hidden', borderWidth: 1, borderColor: C.border, marginBottom: 20 },
  jobsSection: { paddingHorizontal: 20 },
  sectionHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 12 },
  sectionTitle: { fontSize: 16, fontWeight: '500', color: C.ink },
  sectionCount: { fontSize: 11, color: C.muted, letterSpacing: 1, fontWeight: '600' },
  emptyState: { backgroundColor: C.paper, borderWidth: 1, borderColor: C.border, borderRadius: 8, padding: 24, alignItems: 'center' },
  emptyTitle: { fontSize: 15, fontWeight: '500', color: C.ink, marginBottom: 6 },
  emptyText: { fontSize: 13, color: C.muted, textAlign: 'center' },
  jobCard: { backgroundColor: C.paper, borderWidth: 1, borderColor: C.border, borderRadius: 8, padding: 14, marginBottom: 8 },
  urgencyChip: { backgroundColor: '#FAF3E5', paddingHorizontal: 8, paddingVertical: 3, borderRadius: 3, borderWidth: 1, borderColor: '#E8D9B9' },
  urgencyText: { fontSize: 9, color: C.bronze, fontWeight: '700', letterSpacing: 0.8 },
  jobPrice: { fontSize: 18, fontWeight: '500', color: C.forest },
  jobAddr: { fontSize: 13, color: C.ink, flex: 1 },
  jobMeta: { fontSize: 11, color: C.subtle, marginTop: 8 },
});
